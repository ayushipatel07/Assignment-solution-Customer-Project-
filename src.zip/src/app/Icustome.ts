export class Customer {
  id: number;
  firstName: string;
  lastName: string;
  gender: string;
  address: string;
  city: string;
  state: string;
  orders: number;
  orderTotal?: number;

}
